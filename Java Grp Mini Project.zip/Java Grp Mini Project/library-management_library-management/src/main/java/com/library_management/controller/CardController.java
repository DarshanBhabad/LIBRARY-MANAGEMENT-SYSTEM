package com.library.library_management.controller;

import com.library.library_management.model.Card;
import com.library.library_management.service.CardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/cards")
public class CardController {

    @Autowired
    private CardService cardService;

    @GetMapping("/all")
    public List<Card> getAllCards() {
        return cardService.getAllCards();
    }

    @GetMapping("/{id}")
    public Optional<Card> getCardById(@PathVariable Long id) {
        return cardService.getCardById(id);
    }

    @PutMapping("/activate/{id}")
    public String activateCard(@PathVariable Long id) {
        return cardService.activateCard(id);
    }

    @PutMapping("/deactivate/{id}")
    public String deactivateCard(@PathVariable Long id) {
        return cardService.deactivateCard(id);
    }
}
