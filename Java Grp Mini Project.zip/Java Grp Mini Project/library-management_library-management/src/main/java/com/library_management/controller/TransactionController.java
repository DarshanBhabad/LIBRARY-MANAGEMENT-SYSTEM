package com.library.library_management.controller;

import com.library.library_management.model.Transaction;
import com.library.library_management.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/transactions")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @PostMapping("/issue")
    public String issueBook(@RequestParam Long bookId, @RequestParam Long cardId) {
        try {
            return transactionService.issueBook(bookId, cardId);
        } catch (Exception e) {
            return "Issue failed: " + e.getMessage();
        }
    }

    @PostMapping("/return")
    public String returnBook(@RequestParam Long bookId, @RequestParam Long cardId) {
        try {
            return transactionService.returnBook(bookId, cardId);
        } catch (Exception e) {
            return "Return failed: " + e.getMessage();
        }
    }

    @GetMapping("/all")
    public List<Transaction> getAllTransactions() {
        return transactionService.getAllTransactions();
    }
}
