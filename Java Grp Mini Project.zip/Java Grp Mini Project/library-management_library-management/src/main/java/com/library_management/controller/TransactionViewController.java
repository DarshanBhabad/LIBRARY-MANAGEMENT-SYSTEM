package com.library.library_management.controller;

import com.library.library_management.model.Transaction;
import com.library.library_management.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class TransactionViewController {

    @Autowired
    private TransactionService transactionService;

    @GetMapping("/transactions/view")
    public String viewTransactions(Model model) {
        List<Transaction> transactions = transactionService.getAllTransactions();
        model.addAttribute("transactions", transactions);
        return "transaction-list"; // maps to transaction-list.html
    }

    @GetMapping("/transactions/add")
    public String showAddTransactionForm(Model model) {
        model.addAttribute("transaction", new Transaction());
        return "transaction-add"; // maps to transaction-add.html
    }

    @PostMapping("/transactions/add")
    public String addTransaction(@ModelAttribute("transaction") Transaction transaction) {
        transactionService.addTransaction(transaction);
        return "redirect:/transactions/view";
    }
}
