package com.library.library_management.model;

import jakarta.persistence.*;

@Entity
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private boolean available = true;

    @ManyToOne
    private Author author;

    // Getters and setters
}
