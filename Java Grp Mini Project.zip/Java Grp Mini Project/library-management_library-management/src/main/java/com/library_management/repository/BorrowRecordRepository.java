package com.library.library_management.repository;

public class BorrowRecordRepository {

	public BorrowRecordRepository() {
		// TODO Auto-generated constructor stub
	}

}
