package com.library.library_management.repository;

import com.library.library_management.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Long> {
    Student findByEmailId(String emailId);
}
