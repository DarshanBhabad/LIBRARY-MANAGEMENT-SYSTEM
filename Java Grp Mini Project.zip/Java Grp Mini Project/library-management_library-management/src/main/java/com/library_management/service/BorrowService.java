package com.library.library_management.service;

public class BorrowService {

	public BorrowService() {
		// TODO Auto-generated constructor stub
	}

}
