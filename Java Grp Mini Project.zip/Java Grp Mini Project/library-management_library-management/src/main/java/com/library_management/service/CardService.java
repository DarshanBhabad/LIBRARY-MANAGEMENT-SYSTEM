package com.library.library_management.service;

import com.library.library_management.model.Card;
import com.library.library_management.repository.CardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CardService {

    @Autowired
    private CardRepository cardRepository;

    public List<Card> getAllCards() {
        return cardRepository.findAll();
    }

    public Optional<Card> getCardById(Long id) {
        return cardRepository.findById(id);
    }

    public String activateCard(Long id) {
        Optional<Card> cardOpt = cardRepository.findById(id);
        if (cardOpt.isPresent()) {
            Card card = cardOpt.get();
            card.setStatus(Card.Status.ACTIVATED);
            cardRepository.save(card);
            return "Card activated";
        } else {
            return "Card not found";
        }
    }

    public String deactivateCard(Long id) {
        Optional<Card> cardOpt = cardRepository.findById(id);
        if (cardOpt.isPresent()) {
            Card card = cardOpt.get();
            card.setStatus(Card.Status.DEACTIVATED);
            cardRepository.save(card);
            return "Card deactivated";
        } else {
            return "Card not found";
        }
    }
}
