package com.library.library_management.service;

import com.library.library_management.model.Card;
import com.library.library_management.model.Student;
import com.library.library_management.model.User;
import com.library.library_management.repository.CardRepository;
import com.library.library_management.repository.StudentRepository;
import com.library.library_management.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private CardRepository cardRepository;

    @Autowired
    private UserRepository userRepository;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    /**
     * Creates a student with a new card and linked user account.
     */
    public Student createStudent(Student student) {
        // Create and activate card
        Card card = new Card();
        card.setStatus(Card.Status.ACTIVATED);
        cardRepository.save(card);

        // Link card to student
        student.setCard(card);
        Student savedStudent = studentRepository.save(student);

        // Create user login for the student
        User user = new User();
        user.setUsername(student.getEmailId());
        user.setPassword(passwordEncoder.encode("pass123")); // Default password
        user.setAuthorization("STUDENT");
        userRepository.save(user);

        return savedStudent;
    }

    /**
     * Returns all students in the system.
     */
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    /**
     * Returns a student by their ID.
     */
    public Optional<Student> getStudentById(Long id) {
        return studentRepository.findById(id);
    }

    /**
     * Updates a student record.
     */
    public Student updateStudent(Student student) {
        return studentRepository.save(student);
    }

    /**
     * Deletes a student by ID.
     */
    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }

    /**
     * Changes the password for a user account linked to a student.
     */
    public boolean changePassword(String email, String newPassword) {
        User user = userRepository.findByUsername(email);
        if (user != null) {
            user.setPassword(passwordEncoder.encode(newPassword));
            userRepository.save(user);
            return true;
        }
        return false;
    }
}
