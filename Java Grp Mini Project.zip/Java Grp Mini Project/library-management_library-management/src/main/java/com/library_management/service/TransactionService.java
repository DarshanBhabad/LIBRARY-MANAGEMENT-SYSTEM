package com.library.library_management.service;

import com.library.library_management.model.*;
import com.library.library_management.repository.BookRepository;
import com.library.library_management.repository.CardRepository;
import com.library.library_management.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private CardRepository cardRepository;

    @Autowired
    private BookRepository bookRepository;

    private final int MAX_ISSUED_BOOKS = 3;
    private final int FINE_PER_DAY = 5;

    // For form-based transaction creation
    public void addTransaction(Transaction transaction) {
        if (transaction.getTransactionUUID() == null || transaction.getTransactionUUID().isEmpty()) {
            transaction.setTransactionUUID(UUID.randomUUID().toString());
        }
        if (transaction.getDate() == null) {
            transaction.setDate(java.sql.Timestamp.valueOf(LocalDateTime.now()));
        }
        transactionRepository.save(transaction);
    }

    public List<Transaction> getAllTransactions() {
        return transactionRepository.findAll();
    }

    public String issueBook(Long bookId, Long cardId) throws Exception {
        Optional<Card> cardOpt = cardRepository.findById(cardId);
        Optional<Book> bookOpt = bookRepository.findById(bookId);

        if (cardOpt.isEmpty() || bookOpt.isEmpty()) {
            throw new Exception("Invalid card or book id");
        }

        Card card = cardOpt.get();
        Book book = bookOpt.get();

        if (card.getStatus() != Card.Status.ACTIVATED) {
            throw new Exception("Card is not active");
        }

        if (!book.getIsAvailable()) {
            throw new Exception("Book is not available");
        }

        long booksIssued = transactionRepository
                .findByCardCardIdAndBookBookIdAndIsIssueTrueOrderByDateDesc(cardId, bookId)
                .stream()
                .filter(t -> t.getTransactionStatus().equalsIgnoreCase("SUCCESSFUL"))
                .count();

        if (booksIssued >= MAX_ISSUED_BOOKS) {
            throw new Exception("Issue limit reached");
        }

        // mark book unavailable
        book.setIsAvailable(false);
        bookRepository.save(book);

        // create transaction
        Transaction transaction = new Transaction();
        transaction.setTransactionUUID(UUID.randomUUID().toString());
        transaction.setCard(card);
        transaction.setBook(book);
        transaction.setIsIssue(true);
        transaction.setTransactionStatus("SUCCESSFUL");
        transaction.setDate(java.sql.Timestamp.valueOf(LocalDateTime.now()));

        transactionRepository.save(transaction);

        return transaction.getTransactionUUID();
    }

    public String returnBook(Long bookId, Long cardId) throws Exception {
        Optional<Card> cardOpt = cardRepository.findById(cardId);
        Optional<Book> bookOpt = bookRepository.findById(bookId);

        if (cardOpt.isEmpty() || bookOpt.isEmpty()) {
            throw new Exception("Invalid card or book id");
        }

        Card card = cardOpt.get();
        Book book = bookOpt.get();

        if (card.getStatus() != Card.Status.ACTIVATED) {
            throw new Exception("Card is not active");
        }

        if (book.getIsAvailable()) {
            throw new Exception("Book is already marked as available");
        }

        // mark book available
        book.setIsAvailable(true);
        bookRepository.save(book);

        // fetch latest issue transaction
        List<Transaction> transactions = transactionRepository
                .findByCardCardIdAndBookBookIdAndIsIssueTrueOrderByDateDesc(cardId, bookId);

        if (transactions.isEmpty()) {
            throw new Exception("No active issue transaction found for this book & card");
        }

        Transaction lastIssueTransaction = transactions.get(0);
        long daysIssued = ChronoUnit.DAYS.between(
                lastIssueTransaction.getDate().toInstant(),
                java.time.Instant.now());

        int fine = (daysIssued > 7) ? (int) (daysIssued - 7) * FINE_PER_DAY : 0;

        // create return transaction
        Transaction returnTransaction = new Transaction();
        returnTransaction.setTransactionUUID(UUID.randomUUID().toString());
        returnTransaction.setCard(card);
        returnTransaction.setBook(book);
        returnTransaction.setIsIssue(false);
        returnTransaction.setTransactionStatus("SUCCESSFUL");
        returnTransaction.setDate(java.sql.Timestamp.valueOf(LocalDateTime.now()));
        returnTransaction.setFineAmount(fine);

        transactionRepository.save(returnTransaction);

        return "Book returned. Fine: " + fine + ". TransactionId: " + returnTransaction.getTransactionUUID();
    }
}
